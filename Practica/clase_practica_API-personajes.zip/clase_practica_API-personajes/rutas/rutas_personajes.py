from flask import Blueprint, jsonify, request
from modelos.entidades.mago import Mago
from modelos.entidades.guerrero import Guerrero
from modelos.entidades.arma import Arma
from modelos.repositorios.repositorios import obtenerRepoPersonajes

repo_personajes = obtenerRepoPersonajes()

bp_personajes = Blueprint("bp_personajes",__name__)

@bp_personajes.route("/personajes", methods=["GET"])
def obtener_personajes():
    personajes = repo_personajes.obtenerTodos()
    return jsonify([p.toDiccionario() for p in personajes]), 200

@bp_personajes.route("/personajes/<string:nombre>", methods=["GET"])
def obtener_personaje(nombre):
    personaje = repo_personajes.obtenerPorNombre(nombre)
    if personaje != None:
        return jsonify(personaje.toDiccionario()), 200
    else:
        return jsonify({"error": "No se encontró el personaje especificado."}), 400

@bp_personajes.route("/personajes", methods=["POST"])
def crear_personaje():
    if request.is_json:
        datos = request.get_json()
        if "tipo" in datos:
            tipo = datos["tipo"]
            nombre = datos.get("nombre")
            if not repo_personajes.existeNombre(nombre):
                try:
                    if tipo == "guerrero":
                        arma = None
                        if "arma" in datos and datos["arma"] is not None:
                            # convertir diccionario a objeto Arma
                            arma = Arma.fromDiccionario(datos["arma"])
                        personaje = Guerrero(
                            datos["nombre"],
                            datos["ataque"],
                            datos["defensa"],
                            datos["vida"],
                            datos["gritoActivo"],
                            arma
                        )
                        repo_personajes.agregarPersonaje(personaje)
                        return jsonify({"mensaje": "Personaje creado correctamente",}), 201
                    elif tipo == "mago":
                        arma = None
                        if "arma" in datos and datos["arma"] is not None:
                            arma = Arma.fromDiccionario(datos["arma"])
                        personaje = Mago(
                            datos["nombre"],
                            datos["ataque"],
                            datos["defensa"],
                            datos["vida"],
                            datos["mana"],
                            arma
                        )
                        repo_personajes.agregarPersonaje(personaje)
                        return jsonify({"mensaje": "Personaje creado correctamente",}), 201
                    else:
                        return jsonify({"error": "El tipo debe ser 'guerrero' o 'mago'."}), 400
                except Exception as error:
                    return jsonify({"error": f"Error creando el personaje: {str(error)}"}), 400
            return jsonify({"error": "Ya existe un personaje con ese nombre."}), 400
        return jsonify({"error": "Debe especificar el tipo de personaje."}), 400
    return jsonify({"error": "Los datos deben estar en formato JSON."}), 400

@bp_personajes.route("/personajes/<string:nombre>", methods=["PUT"])
def modificar_personaje(nombre):
    if request.is_json:
        datos = request.get_json()
        if "tipo" in datos:
            try:
                if datos["tipo"] == "guerrero":
                    personaje_modificado = Guerrero.fromDiccionario(datos)
                elif datos["tipo"] == "mago":
                    personaje_modificado = Mago.fromDiccionario(datos)
                else:
                    respuesta = {"error": "El tipo de personaje debe ser guerrero o mago."}
                    codigoRespuesta = 400
            except Exception as error:
                respuesta = {"error": "Error creando el objeto personaje.\n" + str(error)}
                codigoRespuesta = 400
            
            if repo_personajes.existeNombre(nombre):
                repo_personajes.modificar(nombre, personaje_modificado)
                respuesta={"Mensaje":"Personaje modificado","personaje":personaje_modificado.toDiccionario()}
                codigoRespuesta = 200
            else:
                respuesta = {"error": "No se encontró el personaje especificado."}
                codigoRespuesta = 404
        else:
            respuesta = {"error": "Debe especificar el tipo de personaje."}
            codigoRespuesta = 400
    else:
        respuesta = {"error": "Los datos deben estar en formato JSON."}
        codigoRespuesta = 400

    return jsonify(respuesta), codigoRespuesta

@bp_personajes.route("/personajes/<string:nombre>", methods=["DELETE"])
def eliminar_personaje(nombre):
    if repo_personajes.existeNombre(nombre):
        repo_personajes.eliminarPorNombre(nombre)
        return jsonify({'mensaje':'Personaje eliminado'}), 200
    else:
        return jsonify({'error':'No se pudo eliminar porque no se encontro'}), 400